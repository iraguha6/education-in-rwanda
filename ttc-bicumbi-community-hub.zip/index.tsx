import React, { useState, useEffect, useCallback, useRef } from 'react';
import ReactDOM from 'react-dom/client';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';


// --- Enums & Constants ---
const Page = {
  Home: 'Home',
  About: 'About',
  Communication: 'Communication',
  News: 'News',
  Forum: 'Forum',
  Apply: 'Apply',
  Contact: 'Contact',
  TeacherDashboard: 'TeacherDashboard',
  LearnerDashboard: 'LearnerDashboard',
};

const NAV_ITEMS = [
  { label: 'Home', page: Page.Home },
  { 
    label: 'About Us', 
    page: Page.About,
    dropdown: [
      { label: 'Mission & Vision', page: Page.About },
      { label: 'Our History', page: Page.About },
      { label: 'Our Values', page: Page.About },
    ]
  },
  { label: 'Communication', page: Page.Communication },
  { label: 'News & Updates', page: Page.News },
  { label: 'Discussion Forum', page: Page.Forum },
  { label: 'Apply Online', page: Page.Apply },
  { label: 'Contact Us', page: Page.Contact },
];

const DASHBOARD_ITEMS = [
  { label: 'Teacher Dashboard', page: Page.TeacherDashboard },
  { label: 'Learner Dashboard', page: Page.LearnerDashboard },
];

const SPLASH_IMAGES = [
  'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3wzOTVlZmZ8MHwxfGFsbHx8fHx8fHx8fDE3MTU4NjAwMzl8&ixlib=rb-4.0.3&q=80&w=1080',
  'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3wzOTVlZmZ8MHwxfGFsbHx8fHx8fHx8fDE3MTU4NjAwMzl8&ixlib=rb-4.0.3&q=80&w=1080',
  'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3wzOTVlZmZ8MHwxfGFsbHx8fHx8fHx8fDE3MTU4NjAwMzl8&ixlib=rb-4.0.3&q=80&w=1080',
];

// --- Icon Components ---
const YouTubeIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6"><path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17" /><path d="m10 15 5-3-5-3z" /></svg>
);
const WhatsAppIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" /></svg>
);
const FacebookIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" /></svg>
);
const TwitterIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6"><path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/></svg>
);
const MenuIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
);
const CloseIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6"><line x1="18" x2="6" y1="6" y2="18"/><line x1="6" x2="18" y1="6" y2="18"/></svg>
);
const UsersIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>;
const BookOpenIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>;
const ClipboardListIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M12 11h4"/><path d="M12 16h4"/><path d="M8 11h.01"/><path d="M8 16h.01"/></svg>;
const TrendingUpIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>;

// --- Common Components ---
const Card = ({ children, className = '' }) => (
  <div className={`bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300 ${className}`}>
    {children}
  </div>
);

// FIX: Update Button component to accept ...rest props (for `type`) and provide a default for onClick to make it optional.
// This single change fixes errors on lines 418, 492, and 516.
const Button = ({ children, onClick = () => {}, className = '', variant = 'primary', ...rest }) => {
  const variants = {
    primary: 'bg-teal-600 hover:bg-teal-700 text-white',
    secondary: 'bg-gray-200 hover:bg-gray-300 text-teal-800'
  };
  return (
    <button onClick={onClick} className={`px-6 py-2 rounded-lg font-semibold transition-transform transform hover:scale-105 duration-300 ${variants[variant]} ${className}`} {...rest}>
      {children}
    </button>
  );
};

const Dropdown = ({ label, items, navigateTo, currentPage, isMainLinkActive, buttonStyle = false }) => {
  const [isOpen, setIsOpen] = useState(false);
  // FIX: Initialize useRef with null and a proper type to fix errors on lines 93, 106, and 135.
  const node = useRef<HTMLDivElement>(null);

  const handleToggle = (e) => {
    e.preventDefault();
    setIsOpen(!isOpen);
  };

  const handleItemClick = (page) => {
    navigateTo(page);
    setIsOpen(false);
  };
  
  const handleClickOutside = useCallback((e) => {
    if (node.current && !node.current.contains(e.target as Node)) {
      setIsOpen(false);
    }
  }, []);

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [handleClickOutside]);
  
  const hasActiveChild = items.some(item => item.page === currentPage);
  const isActive = isMainLinkActive || hasActiveChild;

  const baseClasses = "px-3 py-2 rounded-md text-sm font-medium flex items-center transition-colors duration-200";
  const activeClasses = 'bg-teal-100 text-teal-700';
  const inactiveClasses = 'text-gray-600 hover:bg-teal-50 hover:text-teal-600';

  const buttonClasses = `px-6 py-2 rounded-lg font-semibold transition-transform transform hover:scale-105 duration-300 bg-teal-600 hover:bg-teal-700 text-white flex items-center`;

  const commonProps = {
    onClick: handleToggle,
  };

  const ToggleComponent = buttonStyle ? 'button' : 'a';
  const toggleClasses = buttonStyle ? buttonClasses : `${baseClasses} ${isActive ? activeClasses : inactiveClasses}`;

  return (
    <div className="relative" ref={node}>
      <ToggleComponent {...commonProps} href="#" className={toggleClasses}>
        <span>{label}</span>
        <svg className={`w-4 h-4 ml-1 transition-transform duration-200 ${isOpen ? 'transform rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
      </ToggleComponent>
      {isOpen && (
        <div className={`absolute mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50 ring-1 ring-black ring-opacity-5 ${buttonStyle ? 'right-0' : 'left-0'}`}>
          {items.map(item => (
            <a
              key={item.label}
              href="#"
              onClick={(e) => {
                e.preventDefault();
                handleItemClick(item.page);
              }}
              className={`block px-4 py-2 text-sm w-full text-left ${
                currentPage === item.page ? 'bg-teal-100 text-teal-700' : 'text-gray-700 hover:bg-teal-50'
              }`}
            >
              {item.label}
            </a>
          ))}
        </div>
      )}
    </div>
  );
};

// --- Layout Components ---
const Header = ({ navigateTo, currentPage, isMenuOpen, setIsMenuOpen }) => (
  <header className="bg-white shadow-md sticky top-0 z-50">
    <div className="container mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between h-16">
        <div className="flex-shrink-0 cursor-pointer" onClick={() => navigateTo(Page.Home)}>
          <h1 className="text-2xl font-bold text-teal-700">TTC Bicumbi</h1>
        </div>
        <nav className="hidden md:block">
          <div className="ml-10 flex items-baseline space-x-4">
            {NAV_ITEMS.map(item => (
              item.dropdown ? (
                <Dropdown 
                  key={item.label} 
                  label={item.label} 
                  items={item.dropdown} 
                  navigateTo={navigateTo} 
                  currentPage={currentPage}
                  isMainLinkActive={currentPage === item.page}
                />
              ) : (
                <a key={item.label} href="#" onClick={(e) => { e.preventDefault(); navigateTo(item.page); }}
                  className={`px-3 py-2 rounded-md text-sm font-medium ${currentPage === item.page ? 'bg-teal-100 text-teal-700' : 'text-gray-600 hover:bg-teal-50 hover:text-teal-600'}`}>
                  {item.label}
                </a>
              )
            ))}
          </div>
        </nav>
        <div className="hidden md:block">
          {/* FIX: Add missing required prop 'isMainLinkActive' */}
          <Dropdown
            label="Dashboards"
            items={DASHBOARD_ITEMS}
            navigateTo={navigateTo}
            currentPage={currentPage}
            buttonStyle={true}
            isMainLinkActive={false}
          />
        </div>
        <div className="-mr-2 flex md:hidden">
          <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="bg-white inline-flex items-center justify-center p-2 rounded-md text-teal-600 hover:text-teal-700 hover:bg-teal-100 focus:outline-none">
            {isMenuOpen ? <CloseIcon /> : <MenuIcon />}
          </button>
        </div>
      </div>
    </div>
    {isMenuOpen && (
      <div className="md:hidden">
        <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
          {NAV_ITEMS.map(item => (
            item.dropdown ? (
              <div key={item.label}>
                <h3 className="px-3 pt-2 pb-1 text-xs font-bold text-gray-500 uppercase">{item.label}</h3>
                {item.dropdown.map(subItem => (
                  <a key={subItem.label} href="#" onClick={(e) => { e.preventDefault(); navigateTo(subItem.page); setIsMenuOpen(false); }}
                    className={`block pl-6 pr-3 py-2 rounded-md text-base font-medium ${currentPage === subItem.page ? 'bg-teal-100 text-teal-700' : 'text-gray-600 hover:bg-teal-50 hover:text-teal-600'}`}>
                    {subItem.label}
                  </a>
                ))}
              </div>
            ) : (
              <a key={item.label} href="#" onClick={(e) => { e.preventDefault(); navigateTo(item.page); setIsMenuOpen(false); }}
                className={`block px-3 py-2 rounded-md text-base font-medium ${currentPage === item.page ? 'bg-teal-100 text-teal-700' : 'text-gray-600 hover:bg-teal-50 hover:text-teal-600'}`}>
                {item.label}
              </a>
            )
          ))}
          <div>
            <h3 className="px-3 pt-2 pb-1 text-xs font-bold text-gray-500 uppercase">Dashboards</h3>
            {DASHBOARD_ITEMS.map(item => (
              <a key={item.label} href="#" onClick={(e) => { e.preventDefault(); navigateTo(item.page); setIsMenuOpen(false); }}
                className={`block pl-6 pr-3 py-2 rounded-md text-base font-medium ${currentPage === item.page ? 'bg-teal-100 text-teal-700' : 'text-gray-600 hover:bg-teal-50 hover:text-teal-600'}`}>
                {item.label}
              </a>
            ))}
          </div>
        </div>
      </div>
    )}
  </header>
);

const Footer = () => (
  <footer className="bg-teal-800 text-white">
    <div className="container mx-auto py-8 px-4 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <h2 className="text-xl font-bold mb-2">TTC Bicumbi</h2>
          <p className="text-teal-200">Excellence in Teacher Training.</p>
        </div>
        <div>
          <h3 className="font-semibold mb-2">Quick Links</h3>
          <ul className="space-y-1">
            <li><a href="#" className="hover:text-teal-300">About Us</a></li>
            <li><a href="#" className="hover:text-teal-300">Apply Online</a></li>
            <li><a href="#" className="hover:text-teal-300">Contact Us</a></li>
          </ul>
        </div>
        <div>
          <h3 className="font-semibold mb-2">Connect With Us</h3>
          <div className="flex space-x-4">
            <a href="#" className="hover:text-teal-300"><TwitterIcon /></a>
            <a href="#" className="hover:text-teal-300"><FacebookIcon /></a>
            <a href="#" className="hover:text-teal-300"><WhatsAppIcon /></a>
            <a href="#" className="hover:text-teal-300"><YouTubeIcon /></a>
          </div>
        </div>
      </div>
      <div className="mt-8 border-t border-teal-700 pt-4 text-center text-sm text-teal-200">
        <p>&copy; {new Date().getFullYear()} TTC Bicumbi. All rights reserved.</p>
      </div>
    </div>
  </footer>
);

// --- Page Components ---
const SplashScreen = () => {
  const [currentImage] = useState(SPLASH_IMAGES[Math.floor(Math.random() * SPLASH_IMAGES.length)]);
  return (
    <div className="h-full flex flex-col items-center justify-center bg-teal-600 text-white" 
         style={{backgroundImage: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url(${currentImage})`, backgroundSize: 'cover', backgroundPosition: 'center'}}>
      <h1 className="text-5xl font-extrabold mb-4 animate-fade-in-down">Welcome to TTC Bicumbi</h1>
      <p className="text-xl animate-fade-in-up">The Future of Education Starts Here.</p>
    </div>
  );
};

const HomePage = ({ navigateTo }) => (
  <div className="space-y-12">
    {/* Hero Section */}
    <div className="text-center p-10 rounded-xl bg-white shadow-lg" style={{backgroundImage: `url('https://picsum.photos/seed/hero/1200/400')`, backgroundSize: 'cover', backgroundPosition: 'center'}}>
       <div className="bg-black bg-opacity-50 p-8 rounded-xl">
          <h2 className="text-4xl font-extrabold text-white mb-4">Empowering the Next Generation of Educators</h2>
          <p className="text-lg text-gray-200 mb-8">Join a community dedicated to excellence, innovation, and leadership in education.</p>
          <div className="space-x-4">
            <Button onClick={() => navigateTo(Page.About)}>Learn More</Button>
            <Button onClick={() => navigateTo(Page.Apply)} variant="secondary">Apply Now</Button>
          </div>
        </div>
    </div>

    {/* Quick Info Cards */}
    <div className="grid md:grid-cols-3 gap-8">
      <Card>
        <div className="p-8">
          <h3 className="text-xl font-bold text-teal-700 mb-2">Latest News</h3>
          <p className="text-gray-600 mb-4">Stay updated with our recent achievements and announcements.</p>
          <a href="#" onClick={(e) => { e.preventDefault(); navigateTo(Page.News); }} className="font-semibold text-teal-600 hover:text-teal-800">Read More &rarr;</a>
        </div>
      </Card>
      <Card>
        <div className="p-8">
          <h3 className="text-xl font-bold text-teal-700 mb-2">Our Programs</h3>
          <p className="text-gray-600 mb-4">Explore the diverse range of teacher training programs we offer.</p>
          <a href="#" onClick={(e) => { e.preventDefault(); navigateTo(Page.About); }} className="font-semibold text-teal-600 hover:text-teal-800">View Programs &rarr;</a>
        </div>
      </Card>
      <Card>
        <div className="p-8">
          <h3 className="text-xl font-bold text-teal-700 mb-2">Student Life</h3>
          <p className="text-gray-600 mb-4">Discover our vibrant campus life, clubs, and activities.</p>
          <a href="#" onClick={(e) => { e.preventDefault(); navigateTo(Page.Forum); }} className="font-semibold text-teal-600 hover:text-teal-800">Join the Community &rarr;</a>
        </div>
      </Card>
    </div>
  </div>
);

const AboutPage = () => (
  <div className="bg-white p-8 rounded-xl shadow-lg space-y-8">
      <h2 className="text-3xl font-bold text-center text-teal-700">About TTC Bicumbi</h2>
      <div className="text-gray-700 space-y-4">
          <h3 className="text-2xl font-semibold text-teal-600">Our History</h3>
          <p>Founded with a vision to create a benchmark in teacher education, TTC Bicumbi has been a cornerstone of educational excellence for decades. Our journey is one of continuous growth, innovation, and commitment to shaping proficient educators.</p>
          <h3 className="text-2xl font-semibold text-teal-600">Mission & Vision</h3>
          <p><strong>Mission:</strong> To provide high-quality teacher training through innovative pedagogy, research, and community engagement, fostering educators who are competent, ethical, and ready to meet the challenges of a dynamic world.</p>
          <p><strong>Vision:</strong> To be a leading center for teacher education, recognized for its contribution to educational development and societal progress.</p>
           <h3 className="text-2xl font-semibold text-teal-600">Our Values</h3>
          <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li><strong>Excellence:</strong> We strive for the highest standards in teaching, learning, and research.</li>
              <li><strong>Integrity:</strong> We uphold honesty, ethics, and transparency in all our actions.</li>
              <li><strong>Innovation:</strong> We embrace creativity and forward-thinking to adapt to the evolving educational landscape.</li>
              <li><strong>Community:</strong> We foster a collaborative and supportive environment for all members.</li>
              <li><strong>Leadership:</strong> We aim to develop leaders who will inspire future generations.</li>
          </ul>
          <h3 className="text-2xl font-semibold text-teal-600">Our Team</h3>
          <p>We are proud of our dedicated team of experienced educators, administrators, and support staff who work collaboratively to create a supportive and intellectually stimulating environment for our students.</p>
      </div>
  </div>
);

const CommunicationPage = () => (
  <div className="bg-white p-8 rounded-xl shadow-lg space-y-8">
      <h2 className="text-3xl font-bold text-center text-teal-700">Communication Channels</h2>
      <p className="text-center text-gray-600">We believe in open and effective communication. Here’s how you can get in touch.</p>
      <div className="grid md:grid-cols-2 gap-8 text-gray-700">
          <div>
              <h3 className="text-2xl font-semibold text-teal-600 mb-2">General Inquiries</h3>
              <p><strong>Email:</strong> info@ttcbicumbi.ac.rw</p>
              <p><strong>Phone:</strong> +250 788 123 456</p>
              <p><strong>Office Hours:</strong> Monday - Friday, 8:00 AM - 5:00 PM</p>
          </div>
           <div>
              <h3 className="text-2xl font-semibold text-teal-600 mb-2">Admissions Office</h3>
              <p><strong>Email:</strong> admissions@ttcbicumbi.ac.rw</p>
              <p><strong>Phone:</strong> +250 788 654 321</p>
          </div>
           <div className="md:col-span-2">
              <h3 className="text-2xl font-semibold text-teal-600 mb-2">Social Media</h3>
              <p>Follow us on our social channels for the latest updates, events, and stories from our community.</p>
              <div className="flex space-x-6 mt-4 text-teal-700">
                <a href="#" className="hover:text-teal-500"><TwitterIcon /></a>
                <a href="#" className="hover:text-teal-500"><FacebookIcon /></a>
                <a href="#" className="hover:text-teal-500"><WhatsAppIcon /></a>
                <a href="#" className="hover:text-teal-500"><YouTubeIcon /></a>
              </div>
          </div>
      </div>
  </div>
);

const NewsPage = () => {
  const newsItems = [
    { id: 1, title: "TTC Bicumbi Wins National Teaching Award", date: "2024-05-10", excerpt: "Our institution was recognized for its innovative teaching methodologies and contribution to education reform." },
    { id: 2, title: "Annual Sports Gala Concludes with Great Success", date: "2024-05-02", excerpt: "Students and faculty participated in a week of exciting sporting events, promoting teamwork and physical well-being." },
    { id: 3, title: "New Partnership with Global Education Network", date: "2024-04-25", excerpt: "We are thrilled to announce a new collaboration that will provide international exchange opportunities for our students." },
  ];

  return (
    <div className="space-y-8">
      <h2 className="text-3xl font-bold text-center text-teal-700">News & Updates</h2>
      <div className="space-y-6">
        {newsItems.map(item => (
          <Card key={item.id}>
            <div className="p-6">
              <p className="text-sm text-gray-500 mb-1">{item.date}</p>
              <h3 className="text-xl font-bold text-teal-700 mb-2">{item.title}</h3>
              <p className="text-gray-600">{item.excerpt}</p>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

const ForumPage = () => {
   const threads = [
      { id: 1, title: "Discussion on new curriculum changes", author: "Jane Doe", replies: 15, lastPost: "2 hours ago" },
      { id: 2, title: "Ideas for the upcoming cultural fest", author: "John Smith", replies: 8, lastPost: "5 hours ago" },
      { id: 3, title: "Study group for final exams", author: "Emily White", replies: 22, lastPost: "1 day ago" },
   ];
  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
          <h2 className="text-3xl font-bold text-teal-700">Discussion Forum</h2>
          <Button>Start New Thread</Button>
      </div>
      <Card>
          <div className="overflow-x-auto">
              <table className="min-w-full">
                  <thead className="bg-teal-50">
                      <tr>
                          <th className="text-left py-3 px-4 font-semibold text-sm text-teal-800">Topic</th>
                          <th className="text-left py-3 px-4 font-semibold text-sm text-teal-800">Author</th>
                          <th className="text-center py-3 px-4 font-semibold text-sm text-teal-800">Replies</th>
                          <th className="text-left py-3 px-4 font-semibold text-sm text-teal-800">Last Post</th>
                      </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                      {threads.map(thread => (
                          <tr key={thread.id} className="hover:bg-gray-50">
                              <td className="py-3 px-4"><a href="#" className="font-medium text-teal-600 hover:underline">{thread.title}</a></td>
                              <td className="py-3 px-4 text-gray-600">{thread.author}</td>
                              <td className="py-3 px-4 text-center text-gray-600">{thread.replies}</td>
                              <td className="py-3 px-4 text-gray-600">{thread.lastPost}</td>
                          </tr>
                      ))}
                  </tbody>
              </table>
          </div>
      </Card>
    </div>
  );
};

const ApplyPage = () => {
  const [submitted, setSubmitted] = useState(false);
  const handleSubmit = (e) => {
      e.preventDefault();
      setSubmitted(true);
  };

  if(submitted) {
      return (
          <div className="bg-white p-8 rounded-xl shadow-lg text-center">
              <h2 className="text-3xl font-bold text-teal-700 mb-4">Application Submitted!</h2>
              <p className="text-gray-600">Thank you for your interest in TTC Bicumbi. We have received your application and will be in touch shortly regarding the next steps.</p>
          </div>
      );
  }

  return (
      <div className="bg-white p-8 rounded-xl shadow-lg">
          <h2 className="text-3xl font-bold text-center text-teal-700 mb-6">Apply Online</h2>
          <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                  <div>
                      <label className="block text-sm font-medium text-gray-700">Full Name</label>
                      <input type="text" required className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500" />
                  </div>
                  <div>
                      <label className="block text-sm font-medium text-gray-700">Email Address</label>
                      <input type="email" required className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500" />
                  </div>
              </div>
               <div>
                  <label className="block text-sm font-medium text-gray-700">Program of Interest</label>
                  <select className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500">
                      <option>Early Childhood Education</option>
                      <option>Primary Education</option>
                      <option>Secondary Education - Sciences</option>
                      <option>Secondary Education - Humanities</option>
                  </select>
              </div>
              <div>
                  <label className="block text-sm font-medium text-gray-700">Personal Statement</label>
                  {/* FIX: The `rows` attribute should be a number. */}
                  <textarea rows={4} required className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"></textarea>
              </div>
              <div className="text-center">
                 <Button type="submit">Submit Application</Button>
              </div>
          </form>
      </div>
  );
};

const ContactPage = () => (
    <div className="bg-white p-8 rounded-xl shadow-lg">
      <h2 className="text-3xl font-bold text-center text-teal-700 mb-6">Contact Us</h2>
      <div className="grid md:grid-cols-2 gap-8">
          <form className="space-y-4">
              <div>
                  <label className="block text-sm font-medium text-gray-700">Your Name</label>
                  <input type="text" className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500" />
              </div>
              <div>
                  <label className="block text-sm font-medium text-gray-700">Your Email</label>
                  <input type="email" className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500" />
              </div>
              <div>
                  <label className="block text-sm font-medium text-gray-700">Message</label>
                  {/* FIX: The `rows` attribute should be a number. */}
                  <textarea rows={5} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"></textarea>
              </div>
              <Button>Send Message</Button>
          </form>
          <div className="space-y-4 text-gray-700">
              <h3 className="text-xl font-semibold text-teal-600">Our Location</h3>
              <p>TTC Bicumbi, Rwamagana District, Eastern Province, Rwanda</p>
              <div className="h-64 bg-gray-200 rounded-md flex items-center justify-center">
                  <p className="text-gray-500">[Map Placeholder]</p>
              </div>
          </div>
      </div>
  </div>
);

// --- New Dashboard Components ---
const DashboardCard = ({ title, value, icon, color }) => (
  <Card className={`flex items-center p-4 ${color}`}>
    <div className="mr-4 text-white p-3 rounded-full">{icon}</div>
    <div>
      <p className="text-sm font-medium text-white opacity-90">{title}</p>
      <p className="text-2xl font-bold text-white">{value}</p>
    </div>
  </Card>
);

const TeacherDashboard = () => {
  const studentPerformanceData = [
    { name: 'Grade A', students: 15 },
    { name: 'Grade B', students: 30 },
    { name: 'Grade C', students: 25 },
    { name: 'Grade D', students: 8 },
    { name: 'Grade F', students: 2 },
  ];

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-teal-700">Teacher Dashboard</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <DashboardCard title="Total Students" value="120" icon={<UsersIcon />} color="bg-teal-500" />
        <DashboardCard title="Classes Taught" value="4" icon={<BookOpenIcon />} color="bg-cyan-500" />
        <DashboardCard title="Upcoming Deadlines" value="3" icon={<ClipboardListIcon />} color="bg-amber-500" />
      </div>
      <Card className="p-6">
        <h3 className="text-xl font-semibold text-teal-800 mb-4">Student Performance Overview</h3>
        <div style={{ width: '100%', height: 300 }}>
          <ResponsiveContainer>
            <BarChart data={studentPerformanceData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="students" fill="#14B8A6" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
};

const LearnerDashboard = () => {
  const gradeProgressData = [
    { name: 'Term 1', 'Overall Grade': 78 },
    { name: 'Term 2', 'Overall Grade': 85 },
    { name: 'Term 3', 'Overall Grade': 82 },
    { name: 'Term 4', 'Overall Grade': 91 },
  ];
  return (
     <div className="space-y-6">
      <h2 className="text-3xl font-bold text-teal-700">Learner Dashboard</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <DashboardCard title="Courses Enrolled" value="5" icon={<BookOpenIcon />} color="bg-teal-500" />
        <DashboardCard title="Assignments Due" value="2" icon={<ClipboardListIcon />} color="bg-amber-500" />
        <DashboardCard title="Overall GPA" value="3.8" icon={<TrendingUpIcon />} color="bg-cyan-500" />
      </div>
      <Card className="p-6">
        <h3 className="text-xl font-semibold text-teal-800 mb-4">My Academic Progress</h3>
        <div style={{ width: '100%', height: 300 }}>
          <ResponsiveContainer>
            <LineChart data={gradeProgressData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="Overall Grade" stroke="#06B6D4" strokeWidth={2} activeDot={{ r: 8 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
};


// --- Main App Component ---
const App = () => {
  const [showSplash, setShowSplash] = useState(true);
  const [currentPage, setCurrentPage] = useState(Page.Home);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setShowSplash(false), 2500);
    return () => clearTimeout(timer);
  }, []);

  const navigateTo = (page) => {
    setCurrentPage(page);
    setIsMenuOpen(false);
    window.scrollTo(0, 0); // Scroll to top on page change
  };

  const renderPage = () => {
    switch (currentPage) {
      case Page.Home: return <HomePage navigateTo={navigateTo} />;
      case Page.About: return <AboutPage />;
      case Page.Communication: return <CommunicationPage />;
      case Page.News: return <NewsPage />;
      case Page.Forum: return <ForumPage />;
      case Page.Apply: return <ApplyPage />;
      case Page.Contact: return <ContactPage />;
      case Page.TeacherDashboard: return <TeacherDashboard />;
      case Page.LearnerDashboard: return <LearnerDashboard />;
      default: return <HomePage navigateTo={navigateTo} />;
    }
  };

  if (showSplash) {
    return <SplashScreen />;
  }

  return (
    <div className="min-h-full flex flex-col bg-teal-50">
      <Header navigateTo={navigateTo} currentPage={currentPage} isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      <main className="flex-grow container mx-auto p-4 sm:p-6 lg:p-8">
        {renderPage()}
      </main>
      <Footer />
    </div>
  );
};

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);